
document.getElementById("contatto-form").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Messaggio inviato! Ti contatteremo a breve.");
});
